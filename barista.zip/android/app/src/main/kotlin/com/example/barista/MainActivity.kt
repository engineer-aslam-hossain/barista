package com.example.barista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
